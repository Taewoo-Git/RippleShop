package bithumb_api;
import java.util.HashMap;

public class Main {
    public static void main(String args[]) {
		Api_Client api = new Api_Client("ac156f43c89675e598b1620738e7a2c6", "9880f11123c4e75f84f2da71ab59e806");
	
		HashMap<String, String> rgParams = new HashMap<String, String>();
		rgParams.put("order_currency", "XRP");
		rgParams.put("payment_currency", "KRW");
	
	
		try {
		    String result = api.callApi("/public/ticker/XRP", rgParams).split(",")[2].split("\"")[3];
		    int xrp_current_price = Integer.parseInt(result);
		    System.out.println(xrp_current_price);
		} catch (Exception e) {
		    e.printStackTrace();
		}
		
    }
}

